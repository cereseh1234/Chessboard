import Controller.ChessController;
import Controller.ChessMoveNavigator;
import Model.ChessBoardModel;
import Model.ChessBoardModelImpl;
import View.ChessBoardView;

import javax.swing.*;
import java.awt.*;
import java.io.File;

public class Main {
    private ChessBoardModel model;
    private ChessBoardView view;
    private ChessController controller;
    private ChessMoveNavigator moveNavigator;
    // Use a relative path or let user choose file
    private String FILE_PATH;

    public Main() {
        // Initialize the MVC components
        model = new ChessBoardModelImpl();
        view = new ChessBoardView(model);
        controller = new ChessController(model, view);
        moveNavigator = new ChessMoveNavigator(model);

        // Create file chooser for PGN files
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new javax.swing.filechooser.FileFilter() {
            public boolean accept(File f) {
                return f.getName().toLowerCase().endsWith(".pgn") || f.isDirectory();
            }
            public String getDescription() {
                return "PGN Files (*.pgn)";
            }
        });

        // Create the main application window
        JFrame frame = new JFrame("Chess Board");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create panels
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(view, BorderLayout.CENTER);

        // Create navigation panel
        JPanel navigationPanel = new JPanel();
        JButton firstButton = new JButton("<<");
        JButton prevButton = new JButton("<");
        JButton nextButton = new JButton(">");
        JButton lastButton = new JButton(">>");
        JButton prevGameButton = new JButton("Previous Game");
        JButton nextGameButton = new JButton("Next Game");
        JLabel moveLabel = new JLabel("Move: 0/0");
        JLabel gameLabel = new JLabel("Game: 0/0");

        // Navigation action listeners
        firstButton.addActionListener(e -> {
            moveNavigator.goToStart();
            updateMoveLabel(moveLabel);
            view.repaint();
        });

        prevButton.addActionListener(e -> {
            moveNavigator.goToPreviousMove();
            updateMoveLabel(moveLabel);
            view.repaint();
        });

        nextButton.addActionListener(e -> {
            moveNavigator.goToNextMove();
            updateMoveLabel(moveLabel);
            view.repaint();
        });

        lastButton.addActionListener(e -> {
            moveNavigator.goToEnd();
            updateMoveLabel(moveLabel);
            view.repaint();
        });

        prevGameButton.addActionListener(e -> {
            moveNavigator.previousGame();
            updateGameLabel(gameLabel);
            updateMoveLabel(moveLabel);
            view.repaint();
        });

        nextGameButton.addActionListener(e -> {
            moveNavigator.nextGame();
            updateGameLabel(gameLabel);
            updateMoveLabel(moveLabel);
            view.repaint();
        });

        // Add buttons to navigation panel
        navigationPanel.add(firstButton);
        navigationPanel.add(prevButton);
        navigationPanel.add(moveLabel);
        navigationPanel.add(nextButton);
        navigationPanel.add(lastButton);
        navigationPanel.add(prevGameButton);
        navigationPanel.add(gameLabel);
        navigationPanel.add(nextGameButton);

        // Create control panel
        JPanel controlPanel = new JPanel(new BorderLayout());
        JPanel buttonPanel = new JPanel();
        JButton loadButton = new JButton("Load PGN File");
        JButton initialButton = new JButton("Initial Position");
        JButton clearButton = new JButton("Clear Board");

        // Add action listeners
        loadButton.addActionListener(e -> {
            int returnVal = fileChooser.showOpenDialog(frame);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                FILE_PATH = fileChooser.getSelectedFile().getAbsolutePath();
                loadPGNFile();
                updateGameLabel(gameLabel);
                updateMoveLabel(moveLabel);
            }
        });

        initialButton.addActionListener(e -> loadInitialPosition());
        clearButton.addActionListener(e -> clearBoard());

        // Add buttons to control panel
        buttonPanel.add(loadButton);
        buttonPanel.add(initialButton);
        buttonPanel.add(clearButton);
        controlPanel.add(buttonPanel, BorderLayout.NORTH);
        controlPanel.add(navigationPanel, BorderLayout.SOUTH);

        // Add panels to frame
        mainPanel.add(controlPanel, BorderLayout.SOUTH);
        frame.add(mainPanel);

        // Size and display the window
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void updateMoveLabel(JLabel label) {
        label.setText(String.format("Move: %d/%d",
                moveNavigator.getCurrentMoveIndex(),
                moveNavigator.getTotalMoves()));
    }

    private void updateGameLabel(JLabel label) {
        label.setText(String.format("Game: %d/%d",
                moveNavigator.getCurrentGameIndex() + 1,
                moveNavigator.getTotalGames()));
    }

    private void loadPGNFile() {
        try {
            moveNavigator.parsePGNMoves(FILE_PATH);
            moveNavigator.goToStart();
            view.repaint();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                    "Error loading PGN file: " + e.getMessage(),
                    "File Loading Error",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void loadInitialPosition() {
        moveNavigator.goToStart();
        view.repaint();
    }

    private void clearBoard() {
        model.clear();
        view.repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(
                        UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new Main();
        });
    }
}