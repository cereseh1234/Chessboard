package Model;

import Model.ChessBoardModel;
import Model.ChessPiece;
import Controller.Position;
import java.util.HashMap;
import java.util.Map;

/**
 * Implementation of the ChessBoardModel interface that represents a chess board.
 * This class manages the placement and movement of chess pieces using a HashMap
 * to store the position-piece relationships. The board uses a standard 8x8 grid
 * with coordinates from (0,0) to (7,7).
 */
public class ChessBoardModelImpl implements ChessBoardModel {
    /**
     * Map storing the current state of the chess board.
     * Key: Position object representing a square on the board
     * Value: ChessPiece object representing the piece at that position
     */
    private Map<Position, ChessPiece> board;

    /**
     * Constructs a new empty chess board.
     * Initializes the internal HashMap that will store the pieces.
     */
    public ChessBoardModelImpl() {
        board = new HashMap<>();
    }

    /**
     * Places a chess piece at the specified position on the board.
     * If a piece already exists at the position, it will be replaced.
     *
     * @param pos The position where the piece should be placed
     * @param piece The chess piece to place
     * @throws IllegalArgumentException implicitly if position is invalid
     */
    @Override
    public void placePiece(Position pos, ChessPiece piece) {
        if (isValidPosition(pos)) {
            board.put(pos, piece);
        }
    }

    /**
     * Retrieves the chess piece at the specified position.
     *
     * @param pos The position to check
     * @return The chess piece at the specified position, or null if the position is empty
     */
    @Override
    public ChessPiece getPiece(Position pos) {
        return board.get(pos);
    }

    /**
     * Removes the chess piece at the specified position.
     * If no piece exists at the position, this method does nothing.
     *
     * @param pos The position from which to remove the piece
     */
    @Override
    public void removePiece(Position pos) {
        board.remove(pos);
    }

    /**
     * Removes all pieces from the board, resulting in an empty board.
     */
    @Override
    public void clear() {
        board.clear();
    }

    /**
     * Moves a chess piece from one position to another.
     * If the source position is empty or either position is invalid,
     * the move will fail.
     *
     * @param from The starting position of the piece
     * @param to The destination position for the piece
     * @return true if the move was successful, false otherwise
     */
    @Override
    public boolean movePiece(Position from, Position to) {
        ChessPiece piece = getPiece(from);
        if (piece != null && isValidPosition(to)) {
            // Remove piece from original position
            removePiece(from);
            // Place piece in new position
            placePiece(to, piece);
            return true;
        }
        return false;
    }

    /**
     * Checks if a position is within the valid bounds of the chess board (8x8 grid).
     * Valid coordinates are from 0 to 7 for both row and column.
     *
     * @param pos The position to validate
     * @return true if the position is valid, false otherwise
     */
    private boolean isValidPosition(Position pos) {
        return pos.getRow() >= 0 && pos.getRow() < 8 &&
                pos.getCol() >= 0 && pos.getCol() < 8;
    }
}