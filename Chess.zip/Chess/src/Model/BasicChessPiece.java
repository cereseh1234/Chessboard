package Model;

public class BasicChessPiece implements ChessPiece {
    private char symbol;
    private String color;
    private String type;

    public BasicChessPiece(char symbol, String color, String type) {
        this.symbol = symbol;
        this.color = color;
        this.type = type;
    }

    @Override
    public char getSymbol() { return symbol; }

    @Override
    public String getColor() { return color; }

    @Override
    public String getType() { return type; }

    @Override
    public String toString() {
        return String.format("ChessPiece[type=%s, color=%s, symbol=%c(\\u%04X)]",
                type, color, symbol, (int)symbol);
    }
}