package Model;

import Controller.Position;

public interface ChessBoardModel {
    void placePiece(Position pos, ChessPiece piece);
    ChessPiece getPiece(Position pos);
    void clear();

    // New method for moving pieces
    default boolean movePiece(Position from, Position to) {
        ChessPiece piece = getPiece(from);
        if (piece != null) {
            // Remove piece from original position
            removePiece(from);
            // Place piece in new position
            placePiece(to, piece);
            return true;
        }
        return false;
    }

    // New helper method to remove a piece
    void removePiece(Position pos);
}