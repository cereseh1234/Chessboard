package Model;

public interface ChessPiece {
    char getSymbol();
    String getColor();
    String getType();
}