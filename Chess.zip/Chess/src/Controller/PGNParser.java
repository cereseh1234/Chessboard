package Controller;

import Model.ChessBoardModel;
import Model.BasicChessPiece;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PGNParser {
    private static final Map<String, Character> PIECE_SYMBOLS = new HashMap<>();
    static {
        // White pieces
        PIECE_SYMBOLS.put("K", '♔');
        PIECE_SYMBOLS.put("Q", '♕');
        PIECE_SYMBOLS.put("R", '♖');
        PIECE_SYMBOLS.put("B", '♗');
        PIECE_SYMBOLS.put("N", '♘');
        PIECE_SYMBOLS.put("P", '♙');

        // Black pieces
        PIECE_SYMBOLS.put("k", '♚');
        PIECE_SYMBOLS.put("q", '♛');
        PIECE_SYMBOLS.put("r", '♜');
        PIECE_SYMBOLS.put("b", '♝');
        PIECE_SYMBOLS.put("n", '♞');
        PIECE_SYMBOLS.put("p", '♟');
    }

    public static class Game {
        public Map<String, String> headers;
        public String moves;

        public Game() {
            this.headers = new HashMap<>();
            this.moves = "";
        }
    }

    public static List<Game> loadPGNFile(String filePath) throws IOException {
        List<Game> games = new ArrayList<>();
        Game currentGame = null;
        StringBuilder moveBuilder = null;

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();

                // Skip empty lines
                if (line.isEmpty()) {
                    continue;
                }

                // Check if it's a header line
                if (line.startsWith("[")) {
                    // If we find a new game header and we were processing a game,
                    // save the current game
                    if (line.startsWith("[Event") && currentGame != null && moveBuilder != null) {
                        currentGame.moves = moveBuilder.toString().trim();
                        games.add(currentGame);
                    }

                    // Start a new game if needed
                    if (currentGame == null || line.startsWith("[Event")) {
                        currentGame = new Game();
                        moveBuilder = new StringBuilder();
                    }

                    // Parse header
                    int endBracket = line.lastIndexOf(']');
                    if (endBracket > 0) {
                        String headerContent = line.substring(1, endBracket);
                        int quoteStart = headerContent.indexOf('"');
                        int quoteEnd = headerContent.lastIndexOf('"');
                        if (quoteStart >= 0 && quoteEnd > quoteStart) {
                            String tag = headerContent.substring(0, quoteStart).trim();
                            String value = headerContent.substring(quoteStart + 1, quoteEnd);
                            currentGame.headers.put(tag, value);
                        }
                    }
                }
                // If it's not a header, it must be moves
                else if (currentGame != null && moveBuilder != null) {
                    moveBuilder.append(line).append(" ");
                }
            }


            if (currentGame != null && moveBuilder != null) {
                currentGame.moves = moveBuilder.toString().trim();
                games.add(currentGame);
            }
        }

        return games;
    }

    public static void setupInitialPosition(ChessBoardModel model) {
        // Setup black pieces
        placePiece(model, 0, 0, "r", "black", "rook");
        placePiece(model, 0, 1, "n", "black", "knight");
        placePiece(model, 0, 2, "b", "black", "bishop");
        placePiece(model, 0, 3, "q", "black", "queen");
        placePiece(model, 0, 4, "k", "black", "king");
        placePiece(model, 0, 5, "b", "black", "bishop");
        placePiece(model, 0, 6, "n", "black", "knight");
        placePiece(model, 0, 7, "r", "black", "rook");
        for (int i = 0; i < 8; i++) {
            placePiece(model, 1, i, "p", "black", "pawn");
        }

        // Setup white pieces
        placePiece(model, 7, 0, "R", "white", "rook");
        placePiece(model, 7, 1, "N", "white", "knight");
        placePiece(model, 7, 2, "B", "white", "bishop");
        placePiece(model, 7, 3, "Q", "white", "queen");
        placePiece(model, 7, 4, "K", "white", "king");
        placePiece(model, 7, 5, "B", "white", "bishop");
        placePiece(model, 7, 6, "N", "white", "knight");
        placePiece(model, 7, 7, "R", "white", "rook");
        for (int i = 0; i < 8; i++) {
            placePiece(model, 6, i, "P", "white", "pawn");
        }
    }

    private static void placePiece(ChessBoardModel model, int row, int col,
                                   String pieceCode, String color, String type) {
        char symbol = PIECE_SYMBOLS.get(pieceCode);
        model.placePiece(new Position(row, col),
                new BasicChessPiece(symbol, color, type));
    }
}