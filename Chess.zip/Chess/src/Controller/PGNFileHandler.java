package Controller;

import java.io.*;
import java.nio.file.*;

public class PGNFileHandler {
    /**
     * Creates a sample PGN file with a famous chess game
     */
    public static void createSamplePGN(String filePath) throws IOException {
        String pgnContent = """
                [Event "Famous Game Example"]
                [Site "New York, USA"]
                [Date "2024.01.01"]
                [Round "1"]
                [White "Player1"]
                [Black "Player2"]
                [Result "1-0"]
                
                1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 5. O-O Be7
                6. Re1 b5 7. Bb3 d6 8. c3 O-O 9. h3 Na5 10. Bc2 c5
                11. d4 Qc7 12. Nbd2 cxd4 13. cxd4 Nc6 14. Nb3 a5
                15. Be3 a4 16. Nbd2 Bd7 1-0
                """;

        Files.write(Paths.get(filePath), pgnContent.getBytes());
    }

    /**
     * Reads and validates a PGN file
     */
    public static String readPGNFile(String filePath) throws IOException {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        }
        return content.toString();
    }
}

