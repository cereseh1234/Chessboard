package Controller;

import Model.ChessBoardModel;
import Model.BasicChessPiece;
import java.util.*;

/**
 * ChessMoveNavigator handles the navigation of chess games loaded from PGN files.
 * It manages game states, move execution, and board position tracking.
 */
public class ChessMoveNavigator {
    private final ChessBoardModel model;
    private List<PGNParser.Game> games;           // List of all games loaded from PGN
    private int currentGameIndex;                 // Index of current game being played
    private int currentMoveIndex;                 // Index of current move in the game (-1 means initial position)
    private List<String> currentGameMoves;        // List of moves in the current game
    private List<BoardState> boardStates;         // History of board states for move navigation

    /**
     * Inner class representing a snapshot of the chess board at a particular moment.
     * Used for navigating backwards through moves.
     */
    private static class BoardState {
        Map<Position, BasicChessPiece> pieces;

        /**
         * Creates a deep copy of the current board state
         * @param model The chess board model to copy from
         */
        public BoardState(ChessBoardModel model) {
            this.pieces = new HashMap<>();
            // Create a deep copy of the current board state
            for (int row = 0; row < 8; row++) {
                for (int col = 0; col < 8; col++) {
                    Position pos = new Position(row, col);
                    BasicChessPiece piece = (BasicChessPiece) model.getPiece(pos);
                    if (piece != null) {
                        pieces.put(pos, piece);
                    }
                }
            }
        }
    }

    /**
     * Constructs a new ChessMoveNavigator with an empty game list
     * @param model The chess board model to manipulate
     */
    public ChessMoveNavigator(ChessBoardModel model) {
        this.model = model;
        this.games = new ArrayList<>();
        this.currentGameMoves = new ArrayList<>();
        this.boardStates = new ArrayList<>();
        this.currentGameIndex = 0;
        this.currentMoveIndex = -1;
    }

    /**
     * Advances to the last move of the current game
     */
    public void goToEnd() {
        while (currentMoveIndex < currentGameMoves.size() - 1) {
            goToNextMove();
        }
    }

    /**
     * Loads the previous game in the list if available
     */
    public void previousGame() {
        if (currentGameIndex > 0) {
            currentGameIndex--;
            loadGame(currentGameIndex);
        }
    }

    /**
     * Loads the next game in the list if available
     */
    public void nextGame() {
        if (currentGameIndex < games.size() - 1) {
            currentGameIndex++;
            loadGame(currentGameIndex);
        }
    }

    /**
     * Loads and parses a PGN file containing chess games
     * @param filePath Path to the PGN file
     * @throws Exception If there's an error reading or parsing the file
     */
    public void parsePGNMoves(String filePath) throws Exception {
        games = PGNParser.loadPGNFile(filePath);
        if (!games.isEmpty()) {
            loadGame(0);
        }
    }

    /**
     * Loads a specific game from the parsed games list
     * @param index Index of the game to load
     */
    public void loadGame(int index) {
        if (index >= 0 && index < games.size()) {
            currentGameIndex = index;
            PGNParser.Game game = games.get(index);
            currentGameMoves.clear();
            boardStates.clear();

            // Parse moves, filtering out move numbers and game results
            String[] tokens = game.moves.split("\\s+");
            for (String token : tokens) {
                if (!token.matches("\\d+\\..*") &&
                        !token.equals("1-0") &&
                        !token.equals("0-1") &&
                        !token.equals("1/2-1/2") &&
                        !token.equals("*")) {
                    currentGameMoves.add(token);
                }
            }
            currentMoveIndex = -1;
            goToStart();
        }
    }

    /**
     * Resets the board to the initial chess position
     */
    public void goToStart() {
        currentMoveIndex = -1;
        model.clear();
        PGNParser.setupInitialPosition(model);
        // Save initial position
        boardStates.clear();
        boardStates.add(new BoardState(model));
    }

    /**
     * Executes the next move in the current game if available
     */
    public void goToNextMove() {
        if (currentMoveIndex < currentGameMoves.size() - 1) {
            currentMoveIndex++;
            String move = currentGameMoves.get(currentMoveIndex);
            executeMove(move);

            // Save the new board state
            boardStates.add(new BoardState(model));
        }
    }

    /**
     * Reverts to the previous move in the current game if available
     */
    public void goToPreviousMove() {
        if (currentMoveIndex >= 0) {
            if (currentMoveIndex < boardStates.size()) {
                // Restore the previous board state
                restoreBoardState(boardStates.get(currentMoveIndex));
            }
            currentMoveIndex--;
        }
    }

    /**
     * Executes a chess move in PGN notation
     * @param move The move in PGN notation (e.g., "e4", "Nf3", "O-O")
     */
    private void executeMove(String move) {
        // Remove check/mate symbols
        move = move.replaceAll("[+#]", "");

        boolean isWhiteMove = (currentMoveIndex % 2 == 0);
        String color = isWhiteMove ? "white" : "black";

        // Handle castling moves
        if (move.equals("O-O")) {
            executeCastling(true, color);
            return;
        } else if (move.equals("O-O-O")) {
            executeCastling(false, color);
            return;
        }

        // Parse regular moves
        char pieceType = Character.isUpperCase(move.charAt(0)) ? move.charAt(0) : 'P';
        String destination = move.substring(move.length() - 2);

        // Convert algebraic notation to board position (e.g., "e4" -> row 4, column 4)
        int destCol = destination.charAt(0) - 'a';
        int destRow = 8 - (destination.charAt(1) - '0');

        // Find and move the piece
        Position sourcePos = findPiecePosition(pieceType, color, new Position(destRow, destCol));
        if (sourcePos != null) {
            BasicChessPiece piece = (BasicChessPiece) model.getPiece(sourcePos);
            model.removePiece(sourcePos);
            model.placePiece(new Position(destRow, destCol), piece);
        }
    }

    /**
     * Finds the position of a piece that can make the specified move
     * @param pieceType Type of piece ('P' for pawn, 'N' for knight, etc.)
     * @param color Color of the piece ("white" or "black")
     * @param destPos Destination position
     * @return Source position of the piece, or null if not found
     */
    private Position findPiecePosition(char pieceType, String color, Position destPos) {
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                Position pos = new Position(row, col);
                BasicChessPiece piece = (BasicChessPiece) model.getPiece(pos);
                if (piece != null && piece.getColor().equals(color)) {
                    if (pieceType == 'P' && piece.getType().equals("pawn")) {
                        return pos;
                    } else if (piece.getSymbol() == piece.getType().toUpperCase().charAt(0)) {
                        return pos;
                    }
                }
            }
        }
        return null;
    }

    /**
     * Executes a castling move
     * @param kingSide true for kingside castling (O-O), false for queenside (O-O-O)
     * @param color Color of the pieces moving ("white" or "black")
     */
    private void executeCastling(boolean kingSide, String color) {
        int row = color.equals("white") ? 7 : 0;

        // Move king
        Position kingStart = new Position(row, 4);
        Position kingEnd = new Position(row, kingSide ? 6 : 2);
        BasicChessPiece king = (BasicChessPiece) model.getPiece(kingStart);
        model.removePiece(kingStart);
        model.placePiece(kingEnd, king);

        // Move rook
        Position rookStart = new Position(row, kingSide ? 7 : 0);
        Position rookEnd = new Position(row, kingSide ? 5 : 3);
        BasicChessPiece rook = (BasicChessPiece) model.getPiece(rookStart);
        model.removePiece(rookStart);
        model.placePiece(rookEnd, rook);
    }

    /**
     * Restores the board to a previous state
     * @param state The board state to restore
     */
    private void restoreBoardState(BoardState state) {
        model.clear();
        for (Map.Entry<Position, BasicChessPiece> entry : state.pieces.entrySet()) {
            model.placePiece(entry.getKey(), entry.getValue());
        }
    }

    /**
     * @return The current move number (1-based)
     */
    public int getCurrentMoveIndex() {
        return currentMoveIndex + 1;
    }

    /**
     * @return Total number of moves in the current game
     */
    public int getTotalMoves() {
        return currentGameMoves.size();
    }

    /**
     * @return The index of the current game
     */
    public int getCurrentGameIndex() {
        return currentGameIndex;
    }

    /**
     * @return Total number of games loaded
     */
    public int getTotalGames() {
        return games.size();
    }
}