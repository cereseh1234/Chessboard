package Controller;

/**
 * Represents a position on a chess board using zero-based row and column coordinates.
 * This immutable class provides a way to store and manipulate chess board positions,
 * with proper implementations of equals(), hashCode(), and toString() for use in collections.
 */
public class Position {
    /** The row coordinate (0-7, where 0 is the top row) */
    private final int row;

    /** The column coordinate (0-7, where 0 is the leftmost column) */
    private final int col;

    /**
     * Constructs a new Position with specified row and column coordinates.
     *
     * @param row The row coordinate (0-7)
     * @param col The column coordinate (0-7)
     */
    public Position(int row, int col) {
        this.row = row;
        this.col = col;
    }

    /**
     * @return The row coordinate of this position
     */
    public int getRow() { return row; }

    /**
     * @return The column coordinate of this position
     */
    public int getCol() { return col; }

    /**
     * Compares this Position with another object for equality.
     * Two Positions are equal if they have the same row and column coordinates.
     * This method is crucial for proper functioning when Position is used as a key in HashMaps.
     *
     * @param o The object to compare with
     * @return true if the objects are equal, false otherwise
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Position position = (Position) o;
        return row == position.row && col == position.col;
    }

    /**
     * Generates a hash code for this Position.
     * The implementation ensures that positions with the same coordinates will have the same hash code,
     * which is essential for proper HashMap functionality.
     * Uses the formula: 31 * row + col to create a unique hash for each position.
     *
     * @return A hash code value for this Position
     */
    @Override
    public int hashCode() {
        return 31 * row + col;
    }

    /**
     * Returns a string representation of this Position.
     * The format is "Position(row,col)" where row and col are the coordinate values.
     *
     * @return A string representation of the position
     */
    @Override
    public String toString() {
        return "Position(" + row + "," + col + ")";
    }
}