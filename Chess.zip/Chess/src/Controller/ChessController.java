package Controller;
import Model.BasicChessPiece;
import Model.ChessBoardModel;
import Model.ChessPiece;
import View.ChessBoardView;

import java.util.HashMap;
import java.util.Map;

/**
 * The ChessController class handles the interaction between the chess board model and view.
 * It manages piece placement, movement validation, and game state management.
 */
public class ChessController {
    /** Reference to the chess board model */
    private ChessBoardModel model;

    /** Reference to the chess board view */
    private ChessBoardView view;

    /** Map to store chess piece symbols and their corresponding string representations */
    private Map<String, String> pieceSymbols;

    /**
     * Constructor for the ChessController.
     * Initializes the controller with references to the model and view components.
     *
     * @param model The chess board model that manages the game state
     * @param view The chess board view that handles the visual representation
     */
    public ChessController(ChessBoardModel model, ChessBoardView view) {
        this.model = model;
        this.view = view;
        initializePieceSymbols();
    }

    /**
     * Initializes the mapping between piece names and their symbolic representations.
     * This map is used for creating chess pieces with the correct symbols.
     * K = King, Q = Queen, B = Bishop, N = Knight, R = Rook, P = Pawn
     */
    private void initializePieceSymbols() {
        pieceSymbols = new HashMap<>();
        pieceSymbols.put("king", "K");
        pieceSymbols.put("queen", "Q");
        pieceSymbols.put("bishop", "B");
        pieceSymbols.put("knight", "N");
        pieceSymbols.put("rook", "R");
        pieceSymbols.put("pawn", "P");
    }

    /**
     * Processes a line from a PGN file containing piece information.
     * Each line contains multiple pieces separated by commas.
     * Each piece entry has the format: pieceType:color:position
     *
     * @param line A string containing piece information in the format "type:color:position,type:color:position,..."
     */
    private void processPGNLine(String line) {
        // Split the line into individual piece entries
        String[] pieces = line.split(",");
        for (String piece : pieces) {
            // Split each piece entry into its components
            String[] parts = piece.trim().split(":");
            if (parts.length == 3) {
                String pieceType = parts[0].trim();
                String color = parts[1].trim();
                String position = parts[2].trim();
                placePiece(pieceType, color, position);
            }
        }
    }

    /**
     * Places a chess piece on the board at the specified position.
     * Converts algebraic notation (e.g., "e4") to array indices and creates the appropriate piece.
     *
     * @param pieceType The type of piece (king, queen, bishop, etc.)
     * @param color The color of the piece (white or black)
     * @param position The position in algebraic notation (e.g., "e4")
     */
    private void placePiece(String pieceType, String color, String position) {
        try {
            // Convert algebraic notation to array indices
            // Column 'a' = 0, 'b' = 1, etc.
            int col = position.charAt(0) - 'a';
            // Row '1' = 7, '2' = 6, etc. (inverted because array starts from top)
            int row = 8 - (position.charAt(1) - '0');

            // Validate position and piece type before placing
            if (isValidPosition(row, col) && pieceSymbols.containsKey(pieceType.toLowerCase())) {
                String symbol = pieceSymbols.get(pieceType.toLowerCase());
                ChessPiece piece = new BasicChessPiece(symbol.charAt(0), color, pieceType);
                model.placePiece(new Position(row, col), piece);
            }
        } catch (Exception e) {
            System.err.println("Error placing piece at position " + position + ": " + e.getMessage());
        }
    }

    /**
     * Validates whether a given position is within the chess board boundaries.
     * The chess board is an 8x8 grid with indices from 0 to 7.
     *
     * @param row The row index to validate
     * @param col The column index to validate
     * @return true if the position is valid (within the board boundaries), false otherwise
     */
    private boolean isValidPosition(int row, int col) {
        return row >= 0 && row < 8 && col >= 0 && col < 8;
    }
}

