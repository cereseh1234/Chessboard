package View;

import Controller.Position;
import Model.ChessBoardModel;
import Model.ChessPiece;

import javax.swing.*;
import java.awt.*;

public class ChessBoardView extends JPanel {
    private static final int SQUARE_SIZE = 60;
    private static final Color LIGHT_SQUARE = new Color(240, 217, 181);
    private static final Color DARK_SQUARE = new Color(181, 136, 99);
    private ChessBoardModel model;
    private boolean debugMode = true;  // Enable debug mode

    public ChessBoardView(ChessBoardModel model) {
        this.model = model;
        setPreferredSize(new Dimension(8 * SQUARE_SIZE, 8 * SQUARE_SIZE));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawBoard(g);
        drawPieces(g);

        if (debugMode) {
            drawDebugGrid(g);
        }
    }

    private void drawBoard(Graphics g) {
        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                boolean isLight = (row + col) % 2 == 0;
                g.setColor(isLight ? LIGHT_SQUARE : DARK_SQUARE);
                g.fillRect(col * SQUARE_SIZE, row * SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE);
            }
        }
    }

    private void drawPieces(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        // Try different fonts in order of preference
        Font[] fonts = {
                new Font("DejaVu Sans", Font.PLAIN, 48),
                new Font("Arial Unicode MS", Font.PLAIN, 48),
                new Font("Segoe UI Symbol", Font.PLAIN, 48),
                new Font("Arial", Font.BOLD, 48)
        };

        // Find the first available font that can render chess pieces
        Font chessFont = null;
        for (Font font : fonts) {
            if (font.canDisplay('♔')) {
                chessFont = font;
                break;
            }
        }

        if (chessFont == null) {
            System.err.println("Warning: No suitable font found for chess pieces");
            chessFont = fonts[fonts.length - 1]; // Use last font as fallback
        }

        g2d.setFont(chessFont);
        System.out.println("Using font: " + chessFont.getFontName());

        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 8; col++) {
                Position pos = new Position(row, col);
                ChessPiece piece = model.getPiece(pos);
                if (piece != null) {
                    // Debug print for each piece
                    if (debugMode) {
                        System.out.printf("Drawing piece at (%d,%d): %s%n",
                                row, col, piece.toString());
                    }

                    String symbol = String.valueOf(piece.getSymbol());
                    FontMetrics fm = g2d.getFontMetrics();
                    int x = col * SQUARE_SIZE + (SQUARE_SIZE - fm.stringWidth(symbol)) / 2;
                    int y = row * SQUARE_SIZE + ((SQUARE_SIZE + fm.getHeight()) / 2) - fm.getDescent();

                    // Draw piece with outline
                    if (piece.getColor().equals("white")) {
                        // White pieces
                        g2d.setColor(Color.BLACK);
                        g2d.drawString(symbol, x + 1, y + 1);
                        g2d.setColor(Color.WHITE);
                    } else {
                        // Black pieces
                        g2d.setColor(Color.WHITE);
                        g2d.drawString(symbol, x + 1, y + 1);
                        g2d.setColor(Color.BLACK);
                    }
                    g2d.drawString(symbol, x, y);
                }
            }
        }
    }

    private void drawDebugGrid(Graphics g) {
        g.setColor(Color.RED);
        // Draw grid lines
        for (int i = 0; i <= 8; i++) {
            g.drawLine(i * SQUARE_SIZE, 0, i * SQUARE_SIZE, 8 * SQUARE_SIZE);
            g.drawLine(0, i * SQUARE_SIZE, 8 * SQUARE_SIZE, i * SQUARE_SIZE);
        }
        // Draw coordinates
        g.setFont(new Font("Arial", Font.PLAIN, 10));
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                g.drawString(String.format("(%d,%d)", i, j),
                        j * SQUARE_SIZE + 2,
                        i * SQUARE_SIZE + 12);
            }
        }
    }
}